document
    .getElementById("donationForm")
    .addEventListener("submit", function(event) {

        event.preventDefault();

        let name = document.getElementById("name").value;
        let food = document.getElementById("food").value;
        let quantity = document.getElementById("quantity").value;

        document.getElementById("successMessage").innerHTML =
            "Thank you, " + name +
            "! Your donation of " +
            food + " (" + quantity +
            ") has been successfully submitted.";

        document.getElementById("donationForm").reset();

    });